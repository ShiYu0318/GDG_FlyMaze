"""Install the map editor into an existing FlyMaze checkout, with a guarded rollback."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

ORIGINAL_MAPS_SHA256 = "88894485e3f02c53677e5f524a5390d1aba646dc61aafec7a3e55c6262c1a0ea"
FILES = (
    "src/flymaze/maps.py",
    "src/flymaze/custom_maps.py",
    "src/flymaze/custom_map_runtime.py",
    "src/flymaze/map_editor.py",
    "src/flymaze/editor_assets/index.html",
    "src/flymaze/editor_assets/editor.css",
    "src/flymaze/editor_assets/editor.js",
    "tests/unit/test_custom_maps.py",
    "tests/unit/test_map_editor.py",
    "tests/unit/test_shared_maps.py",
    "tests/integration/test_custom_map_env.py",
    "tests/editor_ui.cjs",
    "maps/custom_left.json",
    "maps/custom_right.json",
    "maps/custom_s_turn.json",
    "maps/custom_race_a.json",
    "maps/custom_raceb.json",
    "docs/MAP_EDITOR.md",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def install(source: Path, target: Path, restore: bool = False) -> None:
    source, target = source.resolve(), target.resolve()
    maps = target / "src/flymaze/maps.py"
    if not (target / "pyproject.toml").is_file() or not maps.is_file():
        raise ValueError(f"not a FlyMaze checkout: {target}")
    if source == target:
        raise ValueError("source and target must differ; pass the original Ubuntu checkout")
    backup = target / "map_editor_backup"
    original = backup / "maps.py"
    manifest = backup / "manifest.json"
    if restore:
        if not original.is_file() or not manifest.is_file():
            raise ValueError("no installation backup found")
        installed_hash = json.loads(manifest.read_text())["installed_maps_sha256"]
        if digest(original) != ORIGINAL_MAPS_SHA256:
            raise ValueError("backup checksum does not match; no files changed")
        if digest(maps) == ORIGINAL_MAPS_SHA256:
            print("Original map loader is already restored.")
            return
        if digest(maps) != installed_hash:
            raise ValueError("maps.py was edited after installation; refusing to overwrite it")
        shutil.copy2(original, maps)
        print("Restored original map loader. Custom JSON maps and editor files were retained.")
        return
    new_hash = digest(source / FILES[0])
    if digest(maps) not in (ORIGINAL_MAPS_SHA256, new_hash):
        raise ValueError("maps.py differs from the uploaded source; no files changed")
    for relative in FILES:
        incoming, existing = source / relative, target / relative
        if not incoming.is_file():
            raise ValueError(f"package file missing: {relative}")
        if relative != FILES[0] and existing.exists() and digest(existing) != digest(incoming):
            raise ValueError(f"existing file differs: {relative}; no files changed")
    backup.mkdir(exist_ok=True)
    if not original.exists():
        if digest(maps) != ORIGINAL_MAPS_SHA256:
            raise ValueError("already modified but original backup is missing; no files changed")
        shutil.copy2(maps, original)
    manifest.write_text(json.dumps({
        "original_maps_sha256": ORIGINAL_MAPS_SHA256, "installed_maps_sha256": new_hash,
        "files": list(FILES),
    }, indent=2) + "\n", encoding="utf-8")
    for relative in FILES:
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / relative, destination)
    print(f"Installed FlyMaze map editor in {target}")
    print(f"cd {target}\nuv run python -m flymaze.map_editor --no-browser")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("target", type=Path, help="existing Ubuntu FlyMaze checkout")
    parser.add_argument("--restore", action="store_true", help="restore the original map loader")
    args = parser.parse_args()
    try:
        install(Path(__file__).parent, args.target, args.restore)
    except (OSError, ValueError, KeyError) as exc:
        parser.exit(1, f"Install stopped: {exc}\n")


if __name__ == "__main__":
    main()
